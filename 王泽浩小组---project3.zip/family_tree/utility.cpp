#include "utility.hpp"

#include <iostream>
#include <conio.h>
using namespace std;

string gets() {
	string s;
	while (int n = _getch()){
		if (n == 27){
			throw 27;
			break;
		}
		else if (n == 13){
			if(s.size()>0){
				cout << endl;
				break;
			}
			else{
				continue;
			}
		}
		else if (n == 8 ){
			if(s.size()>0){
				s.pop_back();
				cout << "\b \b";
			}
			else{
				continue;
			}
		}
		else if(n>=3&&n<=31||n==127){
			continue;
		}
		else{
			cout << char(n);
			s.push_back(char(n));
		}
	}
	return s;
}

istream &operator>>(istream &in, BirthDay &b){//从文件中读取生日的信息
	in >> b.year >> b.month >> b.day;
	return in;
}

ostream &operator<<(ostream &out, BirthDay &b){
	out << b.year << " " << b.month << " " << b.day;
	return out;
}