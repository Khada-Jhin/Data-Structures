#ifndef UTILITY_HPP
#define UTILITY_HPP
#include <string>

using std::string;
using std::istream;
using std::ostream;

// get valid string
string gets();

struct BirthDay{ //生日结构变量
	int year=0; int month=0; int day=0; 
};

istream &operator>>(istream &in, BirthDay &b);

ostream &operator<<(ostream &out, BirthDay &b);

#endif