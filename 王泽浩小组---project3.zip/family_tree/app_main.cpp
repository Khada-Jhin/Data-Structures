#include "family_tree.hpp"
#include <iostream>

using namespace std;

int main(){
	FamilySystem fa;
	fa.menu();
}