# Airport_Schedule

P1 test passed

Add a Makefile