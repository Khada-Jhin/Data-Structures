#include <iostream>
#include <queue>
using namespace std;
struct node {
  int ele;
  node* left;
  node* right;
  node(int e):left(0), right(0){
    ele = e;
  }
};
class Tree{
public:
    Tree(){
        root = NULL ;
    }
	void insert(int ele){
        newnode(root,ele);
    }
//二叉树的先序遍历
    void preOrder(const node * p) {
        if(p != NULL) {
            cout << p->ele << " " ;
            preOrder( p -> left) ;
            preOrder( p -> right) ;
        }
    }
//二叉树的中序遍历
    void inOrder(const node *p) {
        if (p != NULL) {
            inOrder(p -> left);
            cout << p -> ele <<" " ;
            inOrder(p -> right);
        }
    }
//二叉树的后序遍历
    void postOrder(const node *p) {
        if (p != NULL) {
            postOrder(p -> left);
            postOrder(p -> right);
            cout << p->ele <<" " ;
        }
    }
	void levelOrder(node *p) {
		if(p==NULL){
			return;
		}
		queue<node*> que;
		que.push(p);
		while(!que.empty()){
			cout<<que.front()->ele<<" ";
			p=que.front();
			if(p->left!=NULL)
				que.push(p->left);
			if(p->right!=NULL)
				que.push(p->right);
			que.pop();
		}
	}
    void exchange(node* p){
        node* temp=p;
        if(temp!=NULL){
            node* temp1=temp->left;
            temp->left=temp->right;
            temp->right=temp1;
        }
    } 
    void invertTree(node* p) {
        node* temp=p;
        if(temp==NULL) {
            return;
        }
        invertTree(temp->left);//翻转左子树
        invertTree(temp->right);//翻转右子树
        exchange(temp);//交换左子节点与右子节点
        return;
    }
    ~Tree(){
        clear(root) ;
        root=NULL;
    }
    void clear(node* p){
        if(p!=NULL){
            clear ( p -> left ) ;
            clear ( p -> right ) ;
            delete p ;
        }
    }
    node* getroot(){
        return root;
    }
private:
    node *root ;
    bool newnode(node* &p,int ele) {
        if ( p == NULL){
            p = new node(ele);
            return 1;
        }
        else{
            if( ele > p -> ele ){
                return newnode(p->right,ele);
            }
            else{
                return newnode(p->left,ele);
            }
        }
    }	
};
