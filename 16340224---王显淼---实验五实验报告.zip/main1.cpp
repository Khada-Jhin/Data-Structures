#include <iostream>
#include <windows.h>
#include "Tree.hpp"
using namespace std;
int main(){
	Tree tree;
	char c1;
	while(1){
		system("cls");
		cout<<"Binary Tree:"<<endl;
		cout<<"1. insert element"<<endl;
		cout<<"2. show"<<endl;
		cout<<"3. invert"<<endl;
		cout<<"0. quit"<<endl;
		cout<<"input choice:  ";
		cin>>c1;
		if(c1=='1'){
			system("cls");
			cout<<"Insert element :"<<endl<<endl;
			int a,b;
			cout<<"please input the number of elements:"<<endl;
			cin>>a;
			for(int i=0;i<a;i++){
				cout<<"please input element :"<<endl;
				cin>>b;
				tree.insert(b);
			}
			cout<<"insert seccess!"<<endl;
		}
		else if(c1=='2'){
			while(1){
				system("cls");
				cout<<"Show :"<<endl;
				cout<<"1. preorder"<<endl;
				cout<<"2. inorder"<<endl;
				cout<<"3. postorder"<<endl;
				cout<<"4. levelorder"<<endl;
				cout<<"0. quit"<<endl;
				cout<<"input choice:   ";
				char c2;
				cin>>c2;
				if(c2=='1'){
					cout<<"preoder:  ";
					tree.preOrder(tree.getroot());
					cout<<endl;
				}
				else if(c2=='2'){
					cout<<"inorder:  ";
					tree.inOrder(tree.getroot());
					cout<<endl;
				}
				else if(c2=='3'){
					cout<<"postorder:  ";
					tree.postOrder(tree.getroot());
					cout<<endl;
				}
				else if(c2=='4'){
					cout<<"levelorder:  ";
					tree.levelOrder(tree.getroot());
					cout<<endl;
				}
				else if(c2=='0'){
					cout<<"QUit!"<<endl;
					break;
				}
				else{
					cout<<"Wrong command!"<<endl;
				}
				system("pause");
			}
		}
		else if(c1=='3'){
			tree.invertTree(tree.getroot());
			cout<<"it's being inverted!"<<endl;
		}
		else if(c1=='0'){
			cout<<"QUit!"<<endl;
			break;
		}
		else{
			cout<<"Wrong command!"<<endl;
		}
		system("pause");
	}
	return 0;
}
